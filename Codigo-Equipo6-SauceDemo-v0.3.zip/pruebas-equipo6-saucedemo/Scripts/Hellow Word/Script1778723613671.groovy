import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

WebUI.openBrowser('https://www.google.com')

WebUI.waitForPageLoad(5)

WebUI.verifyMatch(WebUI.getUrl(), '.*google.*', true)

WebUI.closeBrowser()
