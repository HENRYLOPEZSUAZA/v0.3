import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.testobject.ConditionType
 
// ============ ARRANGE ============
WebUI.openBrowser('https://www.saucedemo.com')
WebUI.waitForPageLoad(5)
 
// Login
TestObject inputUsername = new TestObject('inputUsername')
inputUsername.addProperty('id', ConditionType.EQUALS, 'user-name')
 
TestObject inputPassword = new TestObject('inputPassword')
inputPassword.addProperty('id', ConditionType.EQUALS, 'password')
 
TestObject btnLogin = new TestObject('btnLogin')
btnLogin.addProperty('id', ConditionType.EQUALS, 'login-button')
 
WebUI.setText(inputUsername, 'standard_user')
WebUI.setText(inputPassword, 'secret_sauce')
WebUI.click(btnLogin)
WebUI.waitForPageLoad(5)
 
// Agregar producto al carrito
TestObject btnAddBackpack = new TestObject('btnAddBackpack')
btnAddBackpack.addProperty('xpath', ConditionType.EQUALS, '//button[@data-test="add-to-cart-sauce-labs-backpack"]')
WebUI.click(btnAddBackpack)
WebUI.delay(1)
 
// Ir al carrito
TestObject cartIcon = new TestObject('cartIcon')
cartIcon.addProperty('xpath', ConditionType.EQUALS, '//a[@class="shopping_cart_link"]')
WebUI.click(cartIcon)
WebUI.waitForPageLoad(5)
 
// Clic en Checkout
TestObject btnCheckout = new TestObject('btnCheckout')
btnCheckout.addProperty('id', ConditionType.EQUALS, 'checkout')
WebUI.click(btnCheckout)
WebUI.waitForPageLoad(5)
 
// ============ ACT ============
TestObject inputFirstName = new TestObject('inputFirstName')
inputFirstName.addProperty('id', ConditionType.EQUALS, 'first-name')
 
TestObject inputLastName = new TestObject('inputLastName')
inputLastName.addProperty('id', ConditionType.EQUALS, 'last-name')
 
TestObject inputZip = new TestObject('inputZip')
inputZip.addProperty('id', ConditionType.EQUALS, 'postal-code')
 
TestObject btnContinue = new TestObject('btnContinue')
btnContinue.addProperty('id', ConditionType.EQUALS, 'continue')
 
WebUI.setText(inputFirstName, 'Juan')
WebUI.setText(inputLastName, 'Perez')
WebUI.setText(inputZip, '050001')
WebUI.click(btnContinue)
WebUI.waitForPageLoad(5)
 
// ============ ASSERT ============
WebUI.verifyMatch(WebUI.getUrl(), '.*checkout-step-two.*', true)
 
TestObject summaryInfo = new TestObject('summaryInfo')
summaryInfo.addProperty('xpath', ConditionType.EQUALS, '//div[@class="summary_info"]')
WebUI.verifyElementPresent(summaryInfo, 5)
 
WebUI.closeBrowser()
