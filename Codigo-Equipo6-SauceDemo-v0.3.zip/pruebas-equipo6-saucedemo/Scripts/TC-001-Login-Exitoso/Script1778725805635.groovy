import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.testobject.ConditionType
 
// ============ ARRANGE ============
WebUI.openBrowser('https://www.saucedemo.com')
WebUI.waitForPageLoad(5)
 
// ============ ACT ============
// Locator por id (estable en SauceDemo)
TestObject inputUsername = new TestObject('inputUsername')
inputUsername.addProperty('id', ConditionType.EQUALS, 'user-name')
 
TestObject inputPassword = new TestObject('inputPassword')
inputPassword.addProperty('id', ConditionType.EQUALS, 'password')
 
TestObject btnLogin = new TestObject('btnLogin')
btnLogin.addProperty('id', ConditionType.EQUALS, 'login-button')
 
WebUI.setText(inputUsername, 'standard_user')
WebUI.setText(inputPassword, 'secret_sauce')
WebUI.click(btnLogin)
 
// ============ ASSERT ============
WebUI.waitForPageLoad(5)
WebUI.verifyMatch(WebUI.getUrl(), '.*inventory.*', true)
 
TestObject titleProducts = new TestObject('titleProducts')
titleProducts.addProperty('class', ConditionType.EQUALS, 'title')
WebUI.verifyElementText(titleProducts, 'Products')
 
WebUI.closeBrowser()
