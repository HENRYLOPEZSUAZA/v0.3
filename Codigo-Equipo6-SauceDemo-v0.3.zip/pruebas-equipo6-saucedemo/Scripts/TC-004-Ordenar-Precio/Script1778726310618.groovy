import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.testobject.ConditionType
 
// ============ ARRANGE ============
WebUI.openBrowser('https://www.saucedemo.com')
WebUI.waitForPageLoad(5)
 
// Login primero
TestObject inputUsername = new TestObject('inputUsername')
inputUsername.addProperty('id', ConditionType.EQUALS, 'user-name')
 
TestObject inputPassword = new TestObject('inputPassword')
inputPassword.addProperty('id', ConditionType.EQUALS, 'password')
 
TestObject btnLogin = new TestObject('btnLogin')
btnLogin.addProperty('id', ConditionType.EQUALS, 'login-button')
 
WebUI.setText(inputUsername, 'standard_user')
WebUI.setText(inputPassword, 'secret_sauce')
WebUI.click(btnLogin)
WebUI.waitForPageLoad(5)
 
// ============ ACT ============
TestObject sortDropdown = new TestObject('sortDropdown')
sortDropdown.addProperty('class', ConditionType.EQUALS, 'product_sort_container')
 
WebUI.selectOptionByValue(sortDropdown, 'lohi', false)
WebUI.delay(1)
 
// ============ ASSERT ============
TestObject firstPrice = new TestObject('firstPrice')
firstPrice.addProperty('xpath', ConditionType.EQUALS, '(//div[@class="inventory_item_price"])[1]')
 
String priceText = WebUI.getText(firstPrice)
WebUI.verifyMatch(priceText, '.*7.99.*', true)
 
WebUI.closeBrowser()

