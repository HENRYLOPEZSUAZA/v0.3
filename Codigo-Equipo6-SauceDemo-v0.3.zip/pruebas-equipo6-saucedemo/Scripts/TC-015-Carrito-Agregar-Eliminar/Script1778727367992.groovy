import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.testobject.ConditionType
 
// ============ ARRANGE ============
WebUI.openBrowser('https://www.saucedemo.com')
WebUI.waitForPageLoad(5)
 
// Login
TestObject inputUsername = new TestObject('inputUsername')
inputUsername.addProperty('id', ConditionType.EQUALS, 'user-name')
 
TestObject inputPassword = new TestObject('inputPassword')
inputPassword.addProperty('id', ConditionType.EQUALS, 'password')
 
TestObject btnLogin = new TestObject('btnLogin')
btnLogin.addProperty('id', ConditionType.EQUALS, 'login-button')
 
WebUI.setText(inputUsername, 'standard_user')
WebUI.setText(inputPassword, 'secret_sauce')
WebUI.click(btnLogin)
WebUI.waitForPageLoad(5)
 
// ============ ACT ============
// Paso 1: Agregar producto
TestObject btnAddBikeLight = new TestObject('btnAddBikeLight')
btnAddBikeLight.addProperty('xpath', ConditionType.EQUALS, '//button[@data-test="add-to-cart-sauce-labs-bike-light"]')
WebUI.click(btnAddBikeLight)
WebUI.delay(1)
 
// Paso 2: Verificar que el badge del carrito muestra "1"
TestObject cartBadge = new TestObject('cartBadge')
cartBadge.addProperty('xpath', ConditionType.EQUALS, '//span[@class="shopping_cart_badge"]')
WebUI.verifyElementText(cartBadge, '1')
 
// Paso 3: Ir al carrito
TestObject cartIcon = new TestObject('cartIcon')
cartIcon.addProperty('xpath', ConditionType.EQUALS, '//a[@class="shopping_cart_link"]')
WebUI.click(cartIcon)
WebUI.waitForPageLoad(5)
 
// Paso 4: Verificar que el producto está en el carrito
TestObject cartItemName = new TestObject('cartItemName')
cartItemName.addProperty('xpath', ConditionType.EQUALS, '//div[@class="inventory_item_name"]')
WebUI.verifyElementText(cartItemName, 'Sauce Labs Bike Light')
 
// Paso 5: Eliminar el producto
TestObject btnRemove = new TestObject('btnRemove')
btnRemove.addProperty('xpath', ConditionType.EQUALS, '//button[@data-test="remove-sauce-labs-bike-light"]')
WebUI.click(btnRemove)
WebUI.delay(2)
 
// ============ ASSERT ============
// Verificar que la página del carrito ya no tiene items visibles
TestObject removedItem = new TestObject('removedItem')
removedItem.addProperty('xpath', ConditionType.EQUALS, '//div[@class="removed_cart_item"]')
WebUI.verifyElementPresent(removedItem, 5)
 
WebUI.closeBrowser()


