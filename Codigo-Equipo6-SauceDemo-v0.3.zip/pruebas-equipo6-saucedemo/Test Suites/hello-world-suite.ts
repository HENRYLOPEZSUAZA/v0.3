<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>hello-world-suite</description>
   <name>hello-world-suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>10</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>c080fc2d-fa70-41bc-aea3-6e27028ec2be</testSuiteGuid>
   <testCaseLink>
      <guid>e059e1ca-77d3-4ba3-88c5-f48f84c499bf</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Hellow Word</testCaseId>
      <usingDataBindingAtTestSuiteLevel>false</usingDataBindingAtTestSuiteLevel>
   </testCaseLink>
</TestSuiteEntity>
